"""Apartado 1: ESCANEO INICIAL.

Reune las caracteristicas obligatorias del punto de acceso / red junto con el
detalle de los dispositivos conectados:

Caracteristicas: SSID, MAC del AP, canal, banda, seguridad, tecnologia 802.11,
marca/modelo, fecha/hora, numero de dispositivos, velocidad de bajada/subida,
ping e intensidad de senal promedio.

Dispositivos: IP, MAC, fabricante, nombre y estado (online/offline).
"""

from __future__ import annotations

from . import inventory, netscan, ping as ping_mod, speedtest, upnp, util, vendor, wifi

_NA = "No determinado"


def _ap_model(gateway: str | None) -> str | None:
    """Intenta obtener marca/modelo del AP via UPnP en la puerta de enlace."""
    if not gateway:
        return None
    try:
        for device in upnp.discover(timeout=2, retries=1):
            if device.get("ip") != gateway:
                continue
            brand = device.get("manufacturer") or ""
            model = device.get("model") or device.get("name") or ""
            combo = f"{brand} {model}".strip()
            if combo:
                return combo
    except Exception:
        pass
    return None


def _signal_fallback(iface: str | None) -> float | None:
    """Lee la intensidad de senal desde /proc/net/wireless si es posible."""
    if not iface:
        return None
    try:
        with open("/proc/net/wireless") as fh:
            for line in fh.readlines()[2:]:
                if line.strip().startswith(iface):
                    parts = line.replace(":", " ").split()
                    return float(parts[3])
    except (OSError, ValueError, IndexError):
        return None
    return None


def collect(do_speedtest: bool = False) -> dict:
    """Recopila todas las caracteristicas obligatorias y los dispositivos."""
    summary: dict = {"fecha_hora": util.now_str()}

    # --- Wi-Fi / punto de acceso -----------------------------------------
    ap = wifi.current()
    iface = util.default_interface()
    if ap:
        summary["ssid"] = ap.get("ssid") or "(oculta)"
        summary["mac_ap"] = ap.get("bssid") or _NA
        summary["canal"] = ap.get("channel") or _NA
        summary["banda"] = ap.get("band") or _NA
        summary["seguridad"] = ap.get("security") or _NA
        summary["tecnologia"] = ap.get("technology") or _NA
        signal = ap.get("signal_avg")
        if signal is None:
            signal = _signal_fallback(ap.get("iface"))
        summary["senal_dbm"] = signal
        summary["_wifi"] = True
    else:
        summary["ssid"] = "No aplica (red cableada)"
        summary["mac_ap"] = _NA
        summary["canal"] = "No aplica"
        summary["banda"] = "No aplica"
        summary["seguridad"] = "No aplica"
        summary["tecnologia"] = _NA
        summary["senal_dbm"] = None
        summary["_wifi"] = False

    gateway = util.get_gateway()
    model = _ap_model(gateway)
    if not model:
        # Fallback: fabricante del AP a partir de la MAC de la puerta de enlace.
        neigh = netscan.neighbors()
        gw_mac = neigh.get(gateway, {}).get("mac") if gateway else None
        if gw_mac:
            brand = vendor.lookup(gw_mac)
            if brand and brand != "Desconocido":
                model = f"{brand} (modelo no identificado)"
    summary["marca_modelo"] = model or "omitir"

    # --- Red y dispositivos ----------------------------------------------
    network = util.local_network(iface)
    devices = netscan.discover(network, ifname=iface, resolve=True)
    summary["red"] = str(network) if network else _NA
    summary["num_dispositivos"] = len(devices)
    summary["dispositivos"] = devices

    # --- Ping -------------------------------------------------------------
    ping_target = gateway or "1.1.1.1"
    stats = ping_mod.icmp(ping_target, count=3, timeout=2)
    summary["ping_ms"] = stats["avg"]
    summary["ping_target"] = ping_target

    # --- Velocidades ------------------------------------------------------
    if do_speedtest:
        result = speedtest.measure()
        summary["vel_bajada"] = result.get("down_mbps")
        summary["vel_subida"] = result.get("up_mbps")
        if summary["ping_ms"] is None:
            summary["ping_ms"] = result.get("ping_ms")
    else:
        summary["vel_bajada"] = None
        summary["vel_subida"] = None

    return summary


def print_summary(summary: dict) -> None:
    util.title("Escaneo inicial - Caracteristicas obligatorias")
    util.kv("AP (SSID)", summary["ssid"])
    util.kv("MAC AP", summary["mac_ap"])
    util.kv("Canal", summary["canal"])
    util.kv("Banda", summary["banda"])
    util.kv("Seguridad", summary["seguridad"])
    util.kv("Tecnologia", summary["tecnologia"])
    util.kv("Marca/Modelo AP", summary["marca_modelo"])
    util.kv("Fecha / Hora", summary["fecha_hora"])
    util.kv("Red", summary["red"])
    util.kv("N dispositivos", summary["num_dispositivos"])
    down = summary.get("vel_bajada")
    up = summary.get("vel_subida")
    util.kv("Velocidad bajada", f"{down} Mbps" if down is not None else "no medida")
    util.kv("Velocidad subida", f"{up} Mbps" if up is not None else "no medida")
    util.kv("Ping", f"{summary['ping_ms']} ms ({summary.get('ping_target')})"
            if summary.get("ping_ms") is not None else "sin respuesta")
    signal = summary.get("senal_dbm")
    util.kv("Intensidad senal (media)", f"{signal} dBm" if signal is not None else "no disponible")


def print_devices(summary: dict) -> None:
    devices = summary.get("dispositivos", [])
    util.title(f"Detalles / Dispositivos conectados ({len(devices)})")
    util.info("Relacion IP <-> MAC, fabricante, nombre y estado:")
    netscan.print_devices(devices)


def run(do_speedtest: bool = False, save_inventory: bool = True,
        export: str | None = None) -> dict:
    """Ejecuta el escaneo inicial completo y lo muestra por terminal."""
    util.info("Iniciando escaneo inicial...")
    summary = collect(do_speedtest=do_speedtest)
    print_summary(summary)
    print_devices(summary)

    if save_inventory:
        new_count = inventory.update(summary["dispositivos"], network=summary["red"])
        util.ok(f"Inventario actualizado ({new_count} nuevos). {inventory.inventory_path()}")

    if export:
        inventory.update(summary["dispositivos"], network=summary["red"])
        path = inventory.export_csv(export)
        util.ok(f"Exportado a {path}")

    return summary


def run_interactive() -> dict:
    util.title("Escanear red")
    do_speedtest = input("Realizar prueba de velocidad (bajada/subida)? [s/N]: ").strip().lower() == "s"
    return run(do_speedtest=do_speedtest)


if __name__ == "__main__":  # pragma: no cover
    run()
