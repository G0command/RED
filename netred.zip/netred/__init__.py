"""SCP-RED: conjunto de herramientas de red para terminal.

El paquete se organiza en dos apartados:

* ``initial``   -> escaneo inicial (caracteristicas obligatorias + dispositivos).
* resto de modulos -> el resto de herramientas de red.

Todo el codigo usa unicamente la libreria estandar de Python y, cuando esta
disponible, binarios del sistema (ping, tracepath, nmcli, avahi-browse...).
Asi se mantiene un consumo de recursos bajo y un arranque rapido.
"""

__version__ = "1.0.0"
__all__ = ["__version__"]
